

// lib/data-structures/PriorityQueue.ts
export class PriorityQueue<T> {
  private heap: Array<{ item: T; priority: number }> = [];

  enqueue(item: T, priority: number): void {
    this.heap.push({ item, priority });
    this.siftUp(this.heap.length - 1);
  }

  dequeue(): T | undefined {
    if (this.isEmpty()) return undefined;
    
    const top = this.heap[0].item;
    const last = this.heap.pop()!;
    
    if (this.heap.length > 0) {
      this.heap[0] = last;
      this.siftDown(0);
    }
    
    return top;
  }

  changePriority(predicate: (item: T) => boolean, newPriority: number): boolean {
    for (let i = 0; i < this.heap.length; i++) {
      if (predicate(this.heap[i].item)) {
        const oldPriority = this.heap[i].priority;
        this.heap[i].priority = newPriority;
        
        if (newPriority < oldPriority) {
          this.siftUp(i);
        } else {
          this.siftDown(i);
        }
        return true;
      }
    }
    return false;
  }

  peek(): T | undefined {
    return this.isEmpty() ? undefined : this.heap[0].item;
  }

  isEmpty(): boolean {
    return this.heap.length === 0;
  }

  size(): number {
    return this.heap.length;
  }

  toArray(): T[] {
    return this.heap.map(h => h.item);
  }

  private siftUp(index: number): void {
    while (index > 0) {
      const parentIndex = Math.floor((index - 1) / 2);
      if (this.heap[index].priority >= this.heap[parentIndex].priority) break;
      
      [this.heap[index], this.heap[parentIndex]] = [this.heap[parentIndex], this.heap[index]];
      index = parentIndex;
    }
  }

  private siftDown(index: number): void {
    while (true) {
      let smallest = index;
      const leftChild = 2 * index + 1;
      const rightChild = 2 * index + 2;

      if (leftChild < this.heap.length && 
          this.heap[leftChild].priority < this.heap[smallest].priority) {
        smallest = leftChild;
      }

      if (rightChild < this.heap.length && 
          this.heap[rightChild].priority < this.heap[smallest].priority) {
        smallest = rightChild;
      }

      if (smallest === index) break;

      [this.heap[index], this.heap[smallest]] = [this.heap[smallest], this.heap[index]];
      index = smallest;
    }
  }
}

// lib/data-structures/CitizenRegistry.ts
import { Citizen } from '../../types';

export class CitizenRegistry {
  private citizens: Map<string, Citizen> = new Map();
  private idByEmail: Map<string, string> = new Map();
  private nameIndex: Map<string, Set<string>> = new Map();

  add(citizen: Citizen): boolean {
    // Check for duplicates by email
    if (this.idByEmail.has(citizen.email)) {
      return false;
    }

    // Store citizen and create indexes
    this.citizens.set(citizen.id, citizen);
    this.idByEmail.set(citizen.email, citizen.id);
    
    // Index by name (normalized)
    const normalizedName = citizen.name.toLowerCase();
    if (!this.nameIndex.has(normalizedName)) {
      this.nameIndex.set(normalizedName, new Set());
    }
    this.nameIndex.get(normalizedName)!.add(citizen.id);

    return true;
  }

  update(id: string, updates: Partial<Citizen>): boolean {
    const citizen = this.citizens.get(id);
    if (!citizen) return false;

    // If email is being updated, check for duplicates
    if (updates.email && updates.email !== citizen.email) {
      if (this.idByEmail.has(updates.email)) {
        return false;
      }
      // Update email index
      this.idByEmail.delete(citizen.email);
      this.idByEmail.set(updates.email, id);
    }

    // Update name index if name is changing
    if (updates.name && updates.name !== citizen.name) {
      const oldName = citizen.name.toLowerCase();
      const newName = updates.name.toLowerCase();
      
      this.nameIndex.get(oldName)?.delete(id);
      if (!this.nameIndex.has(newName)) {
        this.nameIndex.set(newName, new Set());
      }
      this.nameIndex.get(newName)!.add(id);
    }

    const updatedCitizen = { 
      ...citizen, 
      ...updates, 
      updatedAt: new Date().toISOString() 
    };
    this.citizens.set(id, updatedCitizen);
    return true;
  }

  delete(id: string): boolean {
    const citizen = this.citizens.get(id);
    if (!citizen) return false;

    // Remove from all indexes
    this.citizens.delete(id);
    this.idByEmail.delete(citizen.email);
    
    const normalizedName = citizen.name.toLowerCase();
    this.nameIndex.get(normalizedName)?.delete(id);
    if (this.nameIndex.get(normalizedName)?.size === 0) {
      this.nameIndex.delete(normalizedName);
    }

    return true;
  }

  getById(id: string): Citizen | undefined {
    return this.citizens.get(id);
  }

  getByEmail(email: string): Citizen | undefined {
    const id = this.idByEmail.get(email);
    return id ? this.citizens.get(id) : undefined;
  }

  searchByName(query: string): Citizen[] {
    const normalizedQuery = query.toLowerCase();
    const results: Citizen[] = [];

    for (const [name, ids] of this.nameIndex.entries()) {
      if (name.includes(normalizedQuery)) {
        for (const id of ids) {
          const citizen = this.citizens.get(id);
          if (citizen) results.push(citizen);
        }
      }
    }

    return results;
  }

  getAll(): Citizen[] {
    return Array.from(this.citizens.values());
  }

  size(): number {
    return this.citizens.size;
  }
}

// lib/data-structures/CriminalDatabase.ts
import { Criminal } from '../../types';

export class CriminalDatabase {
  private criminals: Map<string, Criminal> = new Map();
  private nameIndex: Map<string, Set<string>> = new Map();
  private threatLevelIndex: Map<string, Set<string>> = new Map();
  private statusIndex: Map<string, Set<string>> = new Map();

  add(criminal: Criminal): boolean {
    this.criminals.set(criminal.id, criminal);
    
    // Index by name
    const normalizedName = criminal.name.toLowerCase();
    if (!this.nameIndex.has(normalizedName)) {
      this.nameIndex.set(normalizedName, new Set());
    }
    this.nameIndex.get(normalizedName)!.add(criminal.id);

    // Index by threat level
    if (!this.threatLevelIndex.has(criminal.threatLevel)) {
      this.threatLevelIndex.set(criminal.threatLevel, new Set());
    }
    this.threatLevelIndex.get(criminal.threatLevel)!.add(criminal.id);

    // Index by status
    if (!this.statusIndex.has(criminal.status)) {
      this.statusIndex.set(criminal.status, new Set());
    }
    this.statusIndex.get(criminal.status)!.add(criminal.id);

    return true;
  }

  findByName(name: string): Criminal[] {
    const normalizedQuery = name.toLowerCase();
    const results: Criminal[] = [];

    for (const [indexName, ids] of this.nameIndex.entries()) {
      if (indexName.includes(normalizedQuery)) {
        for (const id of ids) {
          const criminal = this.criminals.get(id);
          if (criminal) results.push(criminal);
        }
      }
    }

    return results;
  }

  findByThreatLevel(threatLevel: string): Criminal[] {
    const ids = this.threatLevelIndex.get(threatLevel);
    if (!ids) return [];

    return Array.from(ids).map(id => this.criminals.get(id)!).filter(Boolean);
  }

  findByStatus(status: string): Criminal[] {
    const ids = this.statusIndex.get(status);
    if (!ids) return [];

    return Array.from(ids).map(id => this.criminals.get(id)!).filter(Boolean);
  }

  update(id: string, updates: Partial<Criminal>): boolean {
    const criminal = this.criminals.get(id);
    if (!criminal) return false;

    // Update indexes if necessary
    if (updates.threatLevel && updates.threatLevel !== criminal.threatLevel) {
      this.threatLevelIndex.get(criminal.threatLevel)?.delete(id);
      if (!this.threatLevelIndex.has(updates.threatLevel)) {
        this.threatLevelIndex.set(updates.threatLevel, new Set());
      }
      this.threatLevelIndex.get(updates.threatLevel)!.add(id);
    }

    if (updates.status && updates.status !== criminal.status) {
      this.statusIndex.get(criminal.status)?.delete(id);
      if (!this.statusIndex.has(updates.status)) {
        this.statusIndex.set(updates.status, new Set());
      }
      this.statusIndex.get(updates.status)!.add(id);
    }

    const updatedCriminal = { ...criminal, ...updates, updatedAt: new Date().toISOString() };
    this.criminals.set(id, updatedCriminal);
    return true;
  }

  getById(id: string): Criminal | undefined {
    return this.criminals.get(id);
  }

  getAll(): Criminal[] {
    return Array.from(this.criminals.values());
  }

  size(): number {
    return this.criminals.size;
  }
}

// lib/data-structures/EmergencyRequestManager.ts
import { EmergencyRequest, EmergencyPriority, EmergencyStatus } from '../../types';
import { PriorityQueue } from './PriorityQueue';

export class EmergencyRequestManager {
  private requests: Map<string, EmergencyRequest> = new Map();
  private priorityQueue: PriorityQueue<EmergencyRequest> = new PriorityQueue();
  private statusIndex: Map<EmergencyStatus, Set<string>> = new Map();

  addRequest(request: EmergencyRequest): void {
    this.requests.set(request.id, request);
    this.priorityQueue.enqueue(request, request.priority);
    
    // Index by status
    if (!this.statusIndex.has(request.status)) {
      this.statusIndex.set(request.status, new Set());
    }
    this.statusIndex.get(request.status)!.add(request.id);
  }

  getNextHighestPriority(): EmergencyRequest | undefined {
    let nextRequest = this.priorityQueue.dequeue();
    
    // Skip resolved requests
    while (nextRequest && nextRequest.status === 'resolved') {
      nextRequest = this.priorityQueue.dequeue();
    }
    
    return nextRequest;
  }

  updateRequestPriority(id: string, newPriority: EmergencyPriority): boolean {
    const request = this.requests.get(id);
    if (!request) return false;

    // Update in priority queue
    const updated = this.priorityQueue.changePriority(
      (item) => item.id === id,
      newPriority
    );

    if (updated) {
      request.priority = newPriority;
      this.requests.set(id, request);
    }

    return updated;
  }

  updateRequestStatus(id: string, status: EmergencyStatus, assignedAgent?: string): boolean {
    const request = this.requests.get(id);
    if (!request) return false;

    // Update status index
    this.statusIndex.get(request.status)?.delete(id);
    if (!this.statusIndex.has(status)) {
      this.statusIndex.set(status, new Set());
    }
    this.statusIndex.get(status)!.add(id);

    // Update request
    const updatedRequest = { 
      ...request, 
      status, 
      assignedAgent,
      resolvedTime: status === 'resolved' ? new Date().toISOString() : undefined
    };

    // Calculate response time if resolved
    if (status === 'resolved') {
      const reportedTime = new Date(request.reportedTime).getTime();
      const resolvedTime = new Date().getTime();
      updatedRequest.responseTime = Math.floor((resolvedTime - reportedTime) / 1000 / 60); // in minutes
    }

    this.requests.set(id, updatedRequest);
    return true;
  }

  getRequestsByStatus(status: EmergencyStatus): EmergencyRequest[] {
    const ids = this.statusIndex.get(status);
    if (!ids) return [];

    return Array.from(ids).map(id => this.requests.get(id)!).filter(Boolean);
  }

  getRequestById(id: string): EmergencyRequest | undefined {
    return this.requests.get(id);
  }

  getAllRequests(): EmergencyRequest[] {
    return Array.from(this.requests.values());
  }

  getPendingRequests(): EmergencyRequest[] {
    return this.getRequestsByStatus('pending');
  }

  getInProgressRequests(): EmergencyRequest[] {
    return this.getRequestsByStatus('in-progress');
  }

  getResolvedRequests(): EmergencyRequest[] {
    return this.getRequestsByStatus('resolved');
  }

  size(): number {
    return this.requests.size;
  }
}

// lib/data-structures/AgentManager.ts
import { Agent } from '../../types';

export class AgentManager {
  private agents: Map<string, Agent> = new Map();
  private availableAgents: Set<string> = new Set();
  private usernameIndex: Map<string, string> = new Map();

  addAgent(agent: Agent): boolean {
    if (this.usernameIndex.has(agent.username)) {
      return false; // Username already exists
    }

    this.agents.set(agent.id, agent);
    this.usernameIndex.set(agent.username, agent.id);
    
    if (agent.status === 'available') {
      this.availableAgents.add(agent.id);
    }

    return true;
  }

  updateAgentStatus(id: string, status: Agent['status']): boolean {
    const agent = this.agents.get(id);
    if (!agent) return false;

    // Update availability index
    if (status === 'available') {
      this.availableAgents.add(id);
    } else {
      this.availableAgents.delete(id);
    }

    agent.status = status;
    this.agents.set(id, agent);
    return true;
  }

  assignRequest(agentId: string, requestId: string): boolean {
    const agent = this.agents.get(agentId);
    if (!agent) return false;

    agent.assignedRequests.push(requestId);
    
    // Update status to busy if not already
    if (agent.status === 'available') {
      this.updateAgentStatus(agentId, 'busy');
    }

    this.agents.set(agentId, agent);
    return true;
  }

  unassignRequest(agentId: string, requestId: string): boolean {
    const agent = this.agents.get(agentId);
    if (!agent) return false;

    agent.assignedRequests = agent.assignedRequests.filter(id => id !== requestId);
    
    // Update status to available if no more requests
    if (agent.assignedRequests.length === 0 && agent.status === 'busy') {
      this.updateAgentStatus(agentId, 'available');
    }

    this.agents.set(agentId, agent);
    return true;
  }

  getAvailableAgents(): Agent[] {
    return Array.from(this.availableAgents)
      .map(id => this.agents.get(id)!)
      .filter(Boolean);
  }

  getAgentByUsername(username: string): Agent | undefined {
    const id = this.usernameIndex.get(username);
    return id ? this.agents.get(id) : undefined;
  }

  getAgentById(id: string): Agent | undefined {
    return this.agents.get(id);
  }

  getAllAgents(): Agent[] {
    return Array.from(this.agents.values());
  }

  size(): number {
    return this.agents.size;
  }
}

// lib/utils/analytics.ts
import { EmergencyRequest, Analytics, DateRange, EmergencyPriority, EmergencyType } from '../../types';

export const generateAnalytics = (requests: EmergencyRequest[], dateRange: DateRange): Analytics => {
  const filteredRequests = requests.filter(req => {
    const reqDate = new Date(req.reportedTime);
    return reqDate >= dateRange.start && reqDate <= dateRange.end;
  });

  const requestsByPriority: Record<EmergencyPriority, number> = {
    1: 0, 2: 0, 3: 0, 4: 0, 5: 0
  };

  const requestsByType: Record<EmergencyType, number> = {
    'cyber': 0, 'physical': 0, 'infrastructure': 0, 'medical': 0, 'fire': 0
  };

  const requestsByHour: Record<number, number> = {};

  let totalResponseTime = 0;
  let resolvedCount = 0;

  filteredRequests.forEach(req => {
    // Count by priority
    requestsByPriority[req.priority]++;

    // Count by type
    requestsByType[req.type]++;

    // Count by hour
    const hour = new Date(req.reportedTime).getHours();
    requestsByHour[hour] = (requestsByHour[hour] || 0) + 1;

    // Calculate response times
    if (req.status === 'resolved' && req.responseTime) {
      totalResponseTime += req.responseTime;
      resolvedCount++;
    }
  });

  return {
    totalRequests: filteredRequests.length,
    averageResponseTime: resolvedCount > 0 ? Math.round(totalResponseTime / resolvedCount) : 0,
    requestsByPriority,
    requestsByType,
    requestsByHour,
    resolutionRate: filteredRequests.length > 0 ? (resolvedCount / filteredRequests.length) * 100 : 0
  };
};

// lib/data/dummy-data.ts
import { Citizen, Criminal, EmergencyRequest, Agent } from '../../types';

export const dummyCitizens: Citizen[] = [
  {
    id: 'c1',
    name: 'Alice Johnson',
    age: 28,
    nationality: 'American',
    dateOfBirth: '1995-05-15',
    address: '123 Neo Street, District 1',
    email: 'alice.johnson@email.com',
    phone: '+1-555-0101',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z'
  },
  // Add more citizens...
];

export const dummyCriminals: Criminal[] = [
  {
    id: 'cr1',
    name: 'John Doe',
    age: 35,
    nationality: 'Unknown',
    dateOfBirth: '1988-03-22',
    address: 'Unknown',
    email: 'unknown@email.com',
    phone: 'Unknown',
    crimeHistory: [
      {
        id: 'crime1',
        type: 'Cyber Attack',
        description: 'Hacked into city surveillance system',
        date: '2024-02-10T14:30:00Z',
        severity: 'severe'
      }
    ],
    threatLevel: 'critical',
    status: 'at-large',
    lastSeen: '2024-02-10T16:45:00Z',
    createdAt: '2024-02-10T10:00:00Z',
    updatedAt: '2024-02-10T16:45:00Z'
  },
  // Add more criminals...
];

export const dummyEmergencyRequests: EmergencyRequest[] = [
  {
    id: 'er1',
    title: 'Traffic System Malfunction',
    description: 'Multiple traffic lights in District 2 are malfunctioning causing major congestion',
    location: 'District 2, Main Boulevard',
    type: 'infrastructure',
    priority: 1,
    status: 'pending',
    reportedTime: '2024-02-15T08:30:00Z'
  },
  // Add more emergency requests...
];

export const dummyAgents: Agent[] = [
  {
    id: 'a1',
    name: 'Agent Sarah Chen',
    username: 'schen',
    status: 'available',
    specialization: ['cyber', 'infrastructure'],
    assignedRequests: [],
    email: 'sarah.chen@neometropolis.gov',
    badgeNumber: 'NM001'
  },
  {
    id: 'a2',
    name: 'Agent Marcus Rodriguez',
    username: 'mrodriguez',
    status: 'available',
    specialization: ['physical', 'medical'],
    assignedRequests: [],
    email: 'marcus.rodriguez@neometropolis.gov',
    badgeNumber: 'NM002'
  },
  {
    id: 'a3',
    name: 'Agent Emily Watson',
    username: 'ewatson',
    status: 'available',
    specialization: ['fire', 'infrastructure'],
    assignedRequests: [],
    email: 'emily.watson@neometropolis.gov',
    badgeNumber: 'NM003'
  },
  {
    id: 'a4',
    name: 'Agent David Kim',
    username: 'dkim',
    status: 'available',
    specialization: ['cyber', 'physical'],
    assignedRequests: [],
    email: 'david.kim@neometropolis.gov',
    badgeNumber: 'NM004'
  },
  {
    id: 'a5',
    name: 'Agent Lisa Thompson',
    username: 'lthompson',
    status: 'available',
    specialization: ['medical', 'cyber'],
    assignedRequests: [],
    email: 'lisa.thompson@neometropolis.gov',
    badgeNumber: 'NM005'
  }
];

// Pre-assigned agent credentials for login
export const agentCredentials = [
  { username: 'schen', password: 'neo2024!', agentId: 'a1' },
  { username: 'mrodriguez', password: 'neo2024!', agentId: 'a2' },
  { username: 'ewatson', password: 'neo2024!', agentId: 'a3' },
  { username: 'dkim', password: 'neo2024!', agentId: 'a4' },
  { username: 'lthompson', password: 'neo2024!', agentId: 'a5' }
];