import React, { useState, useEffect, useRef } from 'react';
import { 
  Shield, 
  Users, 
  UserX, 
  AlertTriangle, 
  Activity, 
  BarChart3, 
  Search, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Clock, 
  MapPin, 
  User,
  Bell,
  Settings,
  LogOut,
  CheckCircle,
  XCircle,
  AlertCircle,
  Zap,
  TrendingUp,
  Calendar,
  Filter
} from 'lucide-react';

// Global State Management
const useAppState = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [citizens, setCitizens] = useState([]);
  const [criminals, setCriminals] = useState([]);
  const [emergencyRequests, setEmergencyRequests] = useState([]);
  const [agents, setAgents] = useState([]);
  const [notifications, setNotifications] = useState([]);

  return {
    currentUser,
    setCurrentUser,
    citizens,
    setCitizens,
    criminals,
    setCriminals,
    emergencyRequests,
    setEmergencyRequests,
    agents,
    setAgents,
    notifications,
    setNotifications
  };
};

// Authentication Component
const AuthenticationPage = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simulate authentication
    const credentials = [
      { username: 'schen', password: 'neo2024!', agent: { id: 'a1', name: 'Agent Sarah Chen', badgeNumber: 'NM001' } },
      { username: 'mrodriguez', password: 'neo2024!', agent: { id: 'a2', name: 'Agent Marcus Rodriguez', badgeNumber: 'NM002' } },
      { username: 'ewatson', password: 'neo2024!', agent: { id: 'a3', name: 'Agent Emily Watson', badgeNumber: 'NM003' } },
      { username: 'dkim', password: 'neo2024!', agent: { id: 'a4', name: 'Agent David Kim', badgeNumber: 'NM004' } },
      { username: 'lthompson', password: 'neo2024!', agent: { id: 'a5', name: 'Agent Lisa Thompson', badgeNumber: 'NM005' } }
    ];

    const validCredential = credentials.find(c => c.username === username && c.password === password);

    setTimeout(() => {
      if (validCredential) {
        onLogin(validCredential.agent);
      } else {
        setError('Invalid credentials. Use pre-assigned agent accounts.');
      }
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl shadow-2xl p-8 w-full max-w-md border border-white/20">
        <div className="text-center mb-8">
          <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">NeoMetropolis</h1>
          <p className="text-blue-200">Security Response System</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg">
              {error}
            </div>
          )}

          <div>
            <label className="block text-blue-200 text-sm font-medium mb-2">
              Username
            </label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your username"
              required
            />
          </div>

          <div>
            <label className="block text-blue-200 text-sm font-medium mb-2">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your password"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-2"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Authenticating...</span>
              </>
            ) : (
              <>
                <Shield className="w-5 h-5" />
                <span>Access System</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-blue-300 text-sm mb-2">Demo Credentials:</p>
          <div className="text-xs text-blue-200 space-y-1">
            <p>Username: schen | Password: neo2024!</p>
            <p>Username: mrodriguez | Password: neo2024!</p>
            <p>Username: ewatson | Password: neo2024!</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Header Component
const Header = ({ currentUser, onLogout }) => {
  const [showNotifications, setShowNotifications] = useState(false);

  return (
    <header className="bg-white/10 backdrop-blur-lg border-b border-white/20 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-600 w-10 h-10 rounded-full flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">NeoMetropolis</h1>
            <p className="text-blue-200 text-sm">Security Response System</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-colors relative"
            >
              <Bell className="w-5 h-5 text-white" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                3
              </span>
            </button>
          </div>

          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-white font-medium">{currentUser?.name}</p>
              <p className="text-blue-200 text-sm">Badge: {currentUser?.badgeNumber}</p>
            </div>
            <button
              onClick={onLogout}
              className="bg-red-600 hover:bg-red-700 p-2 rounded-lg transition-colors"
            >
              <LogOut className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

// Sidebar Component
const Sidebar = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity },
    { id: 'citizens', label: 'Citizens', icon: Users },
    { id: 'criminals', label: 'Criminals', icon: UserX },
    { id: 'emergency', label: 'Emergency', icon: AlertTriangle },
    { id: 'agents', label: 'Agents', icon: User },
    { id: 'reports', label: 'Reports', icon: BarChart3 }
  ];

  return (
    <aside className="bg-white/5 backdrop-blur-lg w-64 border-r border-white/20 p-6">
      <nav className="space-y-2">
        {menuItems.map(item => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                activeTab === item.id
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'text-blue-200 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
};

// Dashboard Component
const Dashboard = () => {
  const [statusUpdates, setStatusUpdates] = useState([
    { id: '1', message: 'System security breach detected in District 2', priority: 1, timestamp: new Date().toISOString(), type: 'error' },
    { id: '2', message: 'Emergency response team deployed', priority: 2, timestamp: new Date().toISOString(), type: 'warning' },
    { id: '3', message: 'Traffic systems restored in District 1', priority: 3, timestamp: new Date().toISOString(), type: 'success' }
  ]);

  const stats = {
    compromisedSystems: 12,
    operationalSystems: 88,
    activeRequests: 7,
    availableAgents: 4,
    resolvedToday: 23
  };

  return (
    <div className="space-y-6">
      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-red-500/20 backdrop-blur-lg rounded-xl p-6 border border-red-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-200 text-sm font-medium">Compromised Systems</p>
              <p className="text-3xl font-bold text-white">{stats.compromisedSystems}</p>
            </div>
            <XCircle className="w-12 h-12 text-red-400" />
          </div>
        </div>

        <div className="bg-green-500/20 backdrop-blur-lg rounded-xl p-6 border border-green-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-200 text-sm font-medium">Operational Systems</p>
              <p className="text-3xl font-bold text-white">{stats.operationalSystems}</p>
            </div>
            <CheckCircle className="w-12 h-12 text-green-400" />
          </div>
        </div>

        <div className="bg-yellow-500/20 backdrop-blur-lg rounded-xl p-6 border border-yellow-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-200 text-sm font-medium">Active Requests</p>
              <p className="text-3xl font-bold text-white">{stats.activeRequests}</p>
            </div>
            <AlertCircle className="w-12 h-12 text-yellow-400" />
          </div>
        </div>

        <div className="bg-blue-500/20 backdrop-blur-lg rounded-xl p-6 border border-blue-500/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-200 text-sm font-medium">Available Agents</p>
              <p className="text-3xl font-bold text-white">{stats.availableAgents}</p>
            </div>
            <User className="w-12 h-12 text-blue-400" />
          </div>
        </div>
      </div>

      {/* Critical Alerts */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
          <AlertTriangle className="w-6 h-6 text-red-400" />
          <span>Critical Alerts</span>
        </h2>
        <div className="space-y-3">
          {statusUpdates.map(update => (
            <div
              key={update.id}
              className={`p-4 rounded-lg border ${
                update.type === 'error' ? 'bg-red-500/20 border-red-500/30' :
                update.type === 'warning' ? 'bg-yellow-500/20 border-yellow-500/30' :
                'bg-green-500/20 border-green-500/30'
              }`}
            >
              <div className="flex items-start justify-between">
                <p className="text-white font-medium">{update.message}</p>
                <span className="text-xs text-gray-300">
                  {new Date(update.timestamp).toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
          <Clock className="w-6 h-6 text-blue-400" />
          <span>Recent Activity</span>
        </h2>
        <div className="space-y-3">
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <p className="text-white">Emergency request #ER001 resolved by Agent Chen</p>
            <span className="text-xs text-gray-300 ml-auto">2 min ago</span>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
            <p className="text-white">New citizen profile added to database</p>
            <span className="text-xs text-gray-300 ml-auto">5 min ago</span>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg">
            <div className="w-2 h-2 bg-red-400 rounded-full"></div>
            <p className="text-white">Security breach detected in surveillance system</p>
            <span className="text-xs text-gray-300 ml-auto">12 min ago</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Citizens Management Component
const CitizensManagement = () => {
  const [citizens, setCitizens] = useState([
    {
      id: 'c1',
      name: 'Alice Johnson',
      age: 28,
      nationality: 'American',
      email: 'alice.johnson@email.com',
      phone: '+1-555-0101',
      address: '123 Neo Street, District 1'
    },
    {
      id: 'c2',
      name: 'Bob Smith',
      age: 35,
      nationality: 'Canadian',
      email: 'bob.smith@email.com',
      phone: '+1-555-0102',
      address: '456 Cyber Ave, District 2'
    }
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const filteredCitizens = citizens.filter(citizen =>
    citizen.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    citizen.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Citizen Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Add Citizen</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="relative">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search citizens by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Citizens Table */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-white/5">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Name</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Age</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Nationality</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Email</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Phone</th>
                <th className="px-6 py-4 text-left text-sm font-medium text-blue-200">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filteredCitizens.map(citizen => (
                <tr key={citizen.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 text-white font-medium">{citizen.name}</td>
                  <td className="px-6 py-4 text-gray-300">{citizen.age}</td>
                  <td className="px-6 py-4 text-gray-300">{citizen.nationality}</td>
                  <td className="px-6 py-4 text-gray-300">{citizen.email}</td>
                  <td className="px-6 py-4 text-gray-300">{citizen.phone}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <button className="p-2 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-colors">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-green-400 hover:bg-green-500/20 rounded-lg transition-colors">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Criminal Database Component
const CriminalDatabase = () => {
  const [criminals, setCriminals] = useState([
    {
      id: 'cr1',
      name: 'John Shadow',
      threatLevel: 'critical',
      status: 'at-large',
      crimeHistory: ['Cyber Attack', 'Data Breach'],
      lastSeen: '2024-02-10'
    },
    {
      id: 'cr2',
      name: 'Maria Darkweb',
      threatLevel: 'high',
      status: 'in-custody',
      crimeHistory: ['Identity Theft', 'Fraud'],
      lastSeen: '2024-02-08'
    }
  ]);
  const [searchTerm, setSearchTerm] = useState('');

  const getThreatLevelColor = (level) => {
    switch (level) {
      case 'critical': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'high': return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'low': return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'at-large': return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'in-custody': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'released': return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const filteredCriminals = criminals.filter(criminal =>
    criminal.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Criminal Database</h1>
        <div className="flex items-center space-x-4">
          <select className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Threat Levels</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Statuses</option>
            <option value="at-large">At Large</option>
            <option value="in-custody">In Custody</option>
            <option value="released">Released</option>
          </select>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="relative">
          <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search criminals by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Criminal Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCriminals.map(criminal => (
          <div key={criminal.id} className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-start justify-between mb-4">
              <h3 className="text-xl font-bold text-white">{criminal.name}</h3>
              <div className="flex flex-col space-y-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getThreatLevelColor(criminal.threatLevel)}`}>
                  {criminal.threatLevel.toUpperCase()}
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(criminal.status)}`}>
                  {criminal.status.replace('-', ' ').toUpperCase()}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-gray-400 text-sm">Crime History:</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {criminal.crimeHistory.map((crime, index) => (
                    <span key={index} className="bg-red-500/20 text-red-300 px-2 py-1 rounded text-xs">
                      {crime}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-gray-400 text-sm">Last Seen:</p>
                <p className="text-white">{criminal.lastSeen}</p>
              </div>

              <div className="flex items-center space-x-2 pt-4">
                <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors">
                  View Details
                </button>
                <button className="p-2 text-gray-400 hover:bg-white/10 rounded-lg transition-colors">
                  <Edit className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Emergency Requests Component
const EmergencyRequests = () => {
  const [requests, setRequests] = useState([
    {
      id: 'er1',
      title: 'Traffic System Malfunction',
      description: 'Multiple traffic lights malfunctioning in District 2',
      location: 'District 2, Main Boulevard',
      type: 'infrastructure',
      priority: 1,
      status: 'pending',
      reportedTime: '2024-02-15T08:30:00Z'
    },
    {
      id: 'er2',
      title: 'Cyber Attack on Banking System',
      description: 'Suspicious activity detected in banking network',
      location: 'Financial District',
      type: 'cyber',
      priority: 1,
      status: 'in-progress',
      reportedTime: '2024-02-15T09:15:00Z',
      assignedAgent: 'Agent Chen'
    }
  ]);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 1: return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 2: return 'bg-orange-500/20 text-orange-300 border-orange-500/30';
      case 3: return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 4: return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 5: return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'in-progress': return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'resolved': return 'bg-green-500/20 text-green-300 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'cyber': return <Shield className="w-5 h-5" />;
      case 'infrastructure': return <Zap className="w-5 h-5" />;
      case 'physical': return <AlertTriangle className="w-5 h-5" />;
      case 'medical': return <Plus className="w-5 h-5" />;
      case 'fire': return <AlertCircle className="w-5 h-5" />;
      default: return <AlertTriangle className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Emergency Requests</h1>
        <button className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
          <Plus className="w-5 h-5" />
          <span>New Emergency</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center space-x-4">
          <select className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Priorities</option>
            <option value="1">Critical (1)</option>
            <option value="2">High (2)</option>
            <option value="3">Medium (3)</option>
            <option value="4">Low (4)</option>
            <option value="5">Minor (5)</option>
          </select>
          <select className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Types</option>
            <option value="cyber">Cyber</option>
            <option value="infrastructure">Infrastructure</option>
            <option value="physical">Physical</option>
            <option value="medical">Medical</option>
            <option value="fire">Fire</option>
          </select>
          <select className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="in-progress">In Progress</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Emergency Requests List */}
      <div className="space-y-4">
        {requests.map(request => (
          <div key={request.id} className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start space-x-4">
                <div className="bg-red-500/20 p-3 rounded-lg">
                  {getTypeIcon(request.type)}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">{request.title}</h3>
                  <p className="text-gray-300 mb-2">{request.description}</p>
                  <div className="flex items-center space-x-2 text-sm text-gray-400">
                    <MapPin className="w-4 h-4" />
                    <span>{request.location}</span>
                    <span>•</span>
                    <Clock className="w-4 h-4" />
                    <span>{new Date(request.reportedTime).toLocaleString()}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col space-y-2 items-end">
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getPriorityColor(request.priority)}`}>
                  Priority {request.priority}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(request.status)}`}>
                  {request.status.replace('-', ' ').toUpperCase()}
                </span>
              </div>
            </div>

            {request.assignedAgent && (
              <div className="mb-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <p className="text-blue-300 text-sm">
                  <User className="w-4 h-4 inline mr-2" />
                  Assigned to: {request.assignedAgent}
                </p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  request.type === 'cyber' ? 'bg-purple-500/20 text-purple-300' :
                  request.type === 'infrastructure' ? 'bg-yellow-500/20 text-yellow-300' :
                  request.type === 'physical' ? 'bg-red-500/20 text-red-300' :
                  request.type === 'medical' ? 'bg-green-500/20 text-green-300' :
                  'bg-orange-500/20 text-orange-300'
                }`}>
                  {request.type.toUpperCase()}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors">
                  View Details
                </button>
                {request.status === 'pending' && (
                  <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
                    Assign
                  </button>
                )}
                <button className="p-2 text-gray-400 hover:bg-white/10 rounded-lg transition-colors">
                  <Edit className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Agent Dashboard Component
const AgentDashboard = ({ currentUser }) => {
  const [agentStatus, setAgentStatus] = useState('available');
  const [assignedRequests, setAssignedRequests] = useState([
    {
      id: 'er2',
      title: 'Cyber Attack on Banking System',
      priority: 1,
      status: 'in-progress',
      assignedTime: '2024-02-15T09:15:00Z'
    }
  ]);

  const [availableRequests, setAvailableRequests] = useState([
    {
      id: 'er1',
      title: 'Traffic System Malfunction',
      priority: 1,
      status: 'pending',
      reportedTime: '2024-02-15T08:30:00Z'
    }
  ]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'available': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'busy': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'off-duty': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Agent Dashboard</h1>
        <div className="flex items-center space-x-4">
          <span className={`px-4 py-2 rounded-lg border ${getStatusColor(agentStatus)}`}>
            {agentStatus.replace('-', ' ').toUpperCase()}
          </span>
          <select 
            value={agentStatus}
            onChange={(e) => setAgentStatus(e.target.value)}
            className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="available">Available</option>
            <option value="busy">Busy</option>
            <option value="off-duty">Off Duty</option>
          </select>
        </div>
      </div>

      {/* Agent Info Card */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">{currentUser?.name}</h2>
            <p className="text-blue-200">Badge: {currentUser?.badgeNumber}</p>
            <p className="text-gray-300">Specializations: Cyber Security, Infrastructure</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Assigned Requests */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
            <User className="w-6 h-6 text-blue-400" />
            <span>My Assigned Requests ({assignedRequests.length})</span>
          </h2>
          
          <div className="space-y-4">
            {assignedRequests.map(request => (
              <div key={request.id} className="bg-white/5 p-4 rounded-lg border border-white/10">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-white">{request.title}</h3>
                  <span className="bg-red-500/20 text-red-300 px-2 py-1 rounded text-xs">
                    Priority {request.priority}
                  </span>
                </div>
                <p className="text-gray-400 text-sm mb-3">
                  Assigned: {new Date(request.assignedTime).toLocaleString()}
                </p>
                <div className="flex items-center space-x-2">
                  <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm transition-colors">
                    Mark Resolved
                  </button>
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm transition-colors">
                    Update Status
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Available High-Priority Requests */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center space-x-2">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <span>Available High-Priority Requests</span>
          </h2>
          
          <div className="space-y-4">
            {availableRequests.map(request => (
              <div key={request.id} className="bg-white/5 p-4 rounded-lg border border-white/10">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-white">{request.title}</h3>
                  <span className="bg-red-500/20 text-red-300 px-2 py-1 rounded text-xs">
                    Priority {request.priority}
                  </span>
                </div>
                <p className="text-gray-400 text-sm mb-3">
                  Reported: {new Date(request.reportedTime).toLocaleString()}
                </p>
                <div className="flex items-center space-x-2">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm transition-colors">
                    Assign to Me
                  </button>
                  <button className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded text-sm transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-gray-400 text-sm">Requests Resolved Today</p>
              <p className="text-2xl font-bold text-white">5</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-gray-400 text-sm">Avg Response Time</p>
              <p className="text-2xl font-bold text-white">12 min</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-gray-400 text-sm">Success Rate</p>
              <p className="text-2xl font-bold text-white">98%</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Reports and Analytics Component
const ReportsAnalytics = () => {
  const [dateRange, setDateRange] = useState({
    start: '2024-02-01',
    end: '2024-02-15'
  });

  const [analytics, setAnalytics] = useState({
    totalRequests: 145,
    averageResponseTime: 18,
    resolutionRate: 92,
    requestsByPriority: { 1: 25, 2: 35, 3: 45, 4: 30, 5: 10 },
    requestsByType: { cyber: 45, infrastructure: 30, physical: 25, medical: 25, fire: 20 },
    requestsByHour: { 8: 12, 9: 18, 10: 15, 11: 20, 12: 25, 13: 22, 14: 28, 15: 20, 16: 18, 17: 15 }
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Reports & Analytics</h1>
        <div className="flex items-center space-x-4">
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
            className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <span className="text-white">to</span>
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
            className="bg-white/10 border border-white/20 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors">
            Export Report
          </button>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <BarChart3 className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-gray-400 text-sm">Total Requests</p>
              <p className="text-3xl font-bold text-white">{analytics.totalRequests}</p>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-gray-400 text-sm">Avg Response Time</p>
              <p className="text-3xl font-bold text-white">{analytics.averageResponseTime} min</p>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <CheckCircle className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-gray-400 text-sm">Resolution Rate</p>
              <p className="text-3xl font-bold text-white">{analytics.resolutionRate}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <div className="flex items-center space-x-3">
            <TrendingUp className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-gray-400 text-sm">Efficiency Score</p>
              <p className="text-3xl font-bold text-white">A+</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Priority Distribution */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">Requests by Priority</h3>
          <div className="space-y-3">
            {Object.entries(analytics.requestsByPriority).map(([priority, count]) => (
              <div key={priority} className="flex items-center justify-between">
                <span className="text-white">Priority {priority}</span>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${
                        priority === '1' ? 'bg-red-500' :
                        priority === '2' ? 'bg-orange-500' :
                        priority === '3' ? 'bg-yellow-500' :
                        priority === '4' ? 'bg-blue-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${(count / Math.max(...Object.values(analytics.requestsByPriority))) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-white w-8 text-right">{count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Type Distribution */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
          <h3 className="text-xl font-bold text-white mb-4">Requests by Type</h3>
          <div className="space-y-3">
            {Object.entries(analytics.requestsByType).map(([type, count]) => (
              <div key={type} className="flex items-center justify-between">
                <span className="text-white capitalize">{type}</span>
                <div className="flex items-center space-x-3">
                  <div className="w-32 bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full ${
                        type === 'cyber' ? 'bg-purple-500' :
                        type === 'infrastructure' ? 'bg-yellow-500' :
                        type === 'physical' ? 'bg-red-500' :
                        type === 'medical' ? 'bg-green-500' : 'bg-orange-500'
                      }`}
                      style={{ width: `${(count / Math.max(...Object.values(analytics.requestsByType))) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-white w-8 text-right">{count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hourly Activity */}
      <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
        <h3 className="text-xl font-bold text-white mb-4">Emergency Requests by Hour</h3>
        <div className="flex items-end space-x-2 h-64">
          {Object.entries(analytics.requestsByHour).map(([hour, count]) => (
            <div key={hour} className="flex flex-col items-center flex-1">
              <div 
                className="bg-blue-500 w-full rounded-t"
                style={{ height: `${(count / Math.max(...Object.values(analytics.requestsByHour))) * 200}px` }}
              ></div>
              <span className="text-white text-sm mt-2">{hour}:00</span>
              <span className="text-gray-400 text-xs">{count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Main Application Component
const NeoMetropolisApp = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin = (user) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveTab('dashboard');
  };

  if (!currentUser) {
    return <AuthenticationPage onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'citizens':
        return <CitizensManagement />;
      case 'criminals':
        return <CriminalDatabase />;
      case 'emergency':
        return <EmergencyRequests />;
      case 'agents':
        return <AgentDashboard currentUser={currentUser} />;
      case 'reports':
        return <ReportsAnalytics />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
      <Header currentUser={currentUser} onLogout={handleLogout} />
      
      <div className="flex">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default NeoMetropolisApp;